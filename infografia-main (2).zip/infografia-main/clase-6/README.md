# Infografía digital: Revisión de avance

### Clase 6 → 07-12-2021

- - - - - - - 

#### Presentación

Pendiente

- - - - - - - 

#### Exploración

Pendiente

- - - - - - - 

#### Aplicación

Pendiente

- - - - - - - -

###### [← CLASE PASADA](https://github.com/profesorfaco/infografia/tree/main/clase-5) — [CLASE SIGUIENTE →](https://github.com/profesorfaco/infografia/tree/main/clase-7) 
