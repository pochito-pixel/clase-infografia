# Taller: Reformulación del impreso para Web

### Taller → 27-11-2021


- - - - - - - 

#### Presentación

Pendiente

- - - - - - - 

#### Exploración

Pendiente

- - - - - - - 

#### Aplicación

Pendiente

- - - - - - - -
