# JavaScript: Datos y bibliotecas

### Clase 4 → 30-11-2021

- - - - - - - 

#### Presentación

Pendiente

- - - - - - - 

#### Exploración

Pendiente

- - - - - - - 

#### Aplicación

Pendiente

- - - - - - - -

###### [← CLASE PASADA](https://github.com/profesorfaco/infografia/tree/main/clase-3) — [CLASE SIGUIENTE →](https://github.com/profesorfaco/infografia/tree/main/clase-5) 
